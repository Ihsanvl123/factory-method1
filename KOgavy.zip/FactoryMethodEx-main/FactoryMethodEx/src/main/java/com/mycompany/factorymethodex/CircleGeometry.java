/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.factorymethodex;

/**
 *
 * @author matti
 */
public class CircleGeometry implements Geometry {
    @Override
    public void draw() {
        System.out.println("Inside CircleGeometry::draw() method.");
    }
}

